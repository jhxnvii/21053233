const express = require('express');
const axios = require('axios');

const app = express();

// Middleware to log request time
app.use((req, res, next) => {
    const startTime = new Date();
    res.on('finish', () => {
        const endTime = new Date();
        const duration = endTime - startTime;
        console.log(`Request to ${req.method} ${req.originalUrl} finished in ${duration}ms`);
    });
    next();
});

// Export the Express app instance
module.exports = app;
