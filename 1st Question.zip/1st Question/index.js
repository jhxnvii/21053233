const express = require('express');
const axios = require('axios');
const app = express();
app.use(express.json());

let window = [];
const windowSize = 10;

app.post('/numbers/:numberid', async (req, res) => {
    const numberid = req.params.numberid;
    let url = '';
    switch(numberid) {
        case 'p':
            url = 'http://20.244.56.144/test/primes';
            break;
        case 'f':
            url = 'http://28.244.56.144/test/fibo';
            break;
        case 'e':
            url = 'http://20.244.56.144/test/even';
            break;
        case 'r':
            url = 'http://20.244.56.144/test/rand';
            break;
        default:
            return res.status(400).send('Invalid number ID');
    }

    try {
        const response = await axios.get(url);
        const numbers = response.data.numbers;
        const uniqueNumbers = [...new Set(numbers)];
        const windowPrevState = [...window];
        window = uniqueNumbers.slice(-windowSize);
        const avg = window.reduce((a, b) => a + b, 0) / window.length;

        res.json({
            windowPrevState,
            windowCurrState: window,
            numbers: uniqueNumbers,
            avg
        });
    } catch (error) {
        console.error(error);
        res.status(500).send('Error fetching numbers');
    }
});

app.listen(9876, () => console.log('Server running on port 9876'));
